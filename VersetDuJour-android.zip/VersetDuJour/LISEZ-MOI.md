# Verset du jour pour Android

Ce dossier est le projet Android de l'application « Verset du jour ».
L'application complète (verset du jour, prière, plans de lecture, Bible
Louis Segond 1910) est incluse : elle fonctionne hors ligne. Seules les
polices de caractères et le lien Google Agenda demandent Internet.

## Obtenir le fichier APK sans rien installer (avec GitHub, gratuit)

1. Créez un compte gratuit sur https://github.com et connectez-vous.
2. Cliquez sur « + » en haut à droite, puis « New repository ».
   Donnez-lui un nom (par exemple `verset-du-jour`) et cliquez sur « Create repository ».
3. Sur la page du dépôt, cliquez sur « uploading an existing file ».
   Glissez **tout le contenu** de ce dossier (y compris le dossier caché `.github`),
   puis cliquez sur « Commit changes ».
   Astuce : si le dossier `.github` ne s'envoie pas, utilisez l'application
   GitHub Desktop, ou créez le fichier `.github/workflows/build-apk.yml`
   à la main avec « Add file » puis « Create new file » et collez son contenu.
4. Ouvrez l'onglet « Actions ». La construction « Construire l'APK » démarre
   toute seule et prend environ 5 minutes.
5. Quand elle est verte, cliquez dessus. En bas, dans « Artifacts », téléchargez
   `VersetDuJour-apk` : c'est un fichier .zip qui contient `app-debug.apk`.

## Installer l'APK sur le téléphone

1. Envoyez `app-debug.apk` sur votre téléphone (câble, e-mail, Google Drive…).
2. Touchez le fichier. Android demande d'autoriser l'installation
   d'applications de cette source : acceptez pour cette fois.
3. L'icône des mains en prière « Verset du jour » apparaît avec vos applications.

## Avec Android Studio (autre méthode)

Ouvrez ce dossier dans Android Studio, attendez la synchronisation, puis
menu Build > Build App Bundle(s) / APK(s) > Build APK(s).

## Bon à savoir

- C'est une version « debug », faite pour l'installer soi-même. Pour publier
  sur le Google Play Store, il faudra une version signée avec votre propre clé.
- Les données (profil, prières, plans, photo) restent sur le téléphone.
- Texte biblique : Louis Segond 1910, domaine public (édition eBible.org).
